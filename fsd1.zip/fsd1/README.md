# Phone Number Risk Checker - Complete Setup Guide

A web-based phone number risk checker for cyber education in rural communities. This system allows users to check if a phone number has been reported as suspicious and report scam/spam numbers.

## 🌟 Features

- **Phone Number Risk Checking**: Check any phone number against community reports
- **Risk Scoring System**: Automatic risk calculation (LOW/MEDIUM/HIGH)
- **Report Submission**: Allow users to report suspicious numbers
- **Real-time Statistics**: Track total reports and high-risk numbers
- **Educational Content**: Built-in cyber safety education
- **Rate Limiting**: Prevents spam and abuse
- **Firebase Integration**: Scalable cloud database
- **Mobile-Friendly**: Responsive design for all devices

## 📋 Prerequisites

- Python 3.8 or higher
- Firebase account (free tier works fine)
- Basic knowledge of command line

## 🚀 Quick Setup

### Step 1: Firebase Setup

1. **Create Firebase Project:**
   - Go to https://console.firebase.google.com/
   - Click "Add project"
   - Name it (e.g., "phone-risk-checker")
   - Disable Google Analytics (optional)
   - Click "Create project"

2. **Create Firestore Database:**
   - In Firebase Console, go to "Build" → "Firestore Database"
   - Click "Create database"
   - Select "Start in test mode" (for development)
   - Choose a location closest to your users
   - Click "Enable"

3. **Get Service Account Key:**
   - Go to Project Settings (gear icon) → "Service accounts"
   - Click "Generate new private key"
   - Download the JSON file
   - Rename it to `serviceAccountKey.json`
   - Place it in the project root directory (same folder as app.py)

### Step 2: Install Python Dependencies

```bash
# Install required packages
pip install -r requirements.txt
```

### Step 3: Configure Environment

```bash
# Copy the example environment file
cp .env.example .env

# Edit .env and set your API key
# API_KEY=your-secret-random-key-here
```

Generate a secure API key (optional, for future use):
```bash
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

### Step 4: Run the Application

```bash
# Start the Flask server
python app.py
```

The API will be available at: `http://localhost:5000`

### Step 5: Open the Web Interface

Open `index.html` in your web browser, or serve it using a simple HTTP server:

```bash
# Python 3
python -m http.server 8000

# Then open: http://localhost:8000
```

## 📁 Project Structure

```
phone-risk-checker/
├── app.py                      # Main Flask application
├── requirements.txt            # Python dependencies
├── .env.example               # Environment variables template
├── serviceAccountKey.json     # Firebase credentials (not in git)
├── index.html                 # Frontend interface
└── README.md                  # This file
```

## 🔧 API Endpoints

### 1. Health Check
```
GET /api/health
```
Returns server health status and Firebase connection.

### 2. Check Phone Number
```
POST /api/check-number
Content-Type: application/json

{
  "phone": "9876543210"
}
```
Returns risk assessment for the phone number.

### 3. Report Phone Number
```
POST /api/report-number
Content-Type: application/json

{
  "phone": "9876543210",
  "category": "scam",
  "description": "Called claiming to be from bank"
}
```
Submit a report for a suspicious number.

Categories: `scam`, `spam`, `fraud`, `harassment`, `other`

### 4. Block Number
```
POST /api/block-number
Content-Type: application/json

{
  "phone": "9876543210"
}
```
Mark a number as blocked (increases risk score).

### 5. Get Statistics
```
GET /api/stats
```
Returns overall system statistics.

## 🗄️ Firebase Database Structure

### Collection: `phone_numbers`
```javascript
{
  "phone": "9876543210",
  "report_count": 5,
  "categories": {
    "scam": 3,
    "spam": 2
  },
  "blocked_count": 2,
  "first_seen": Timestamp,
  "last_reported": Timestamp,
  "last_checked": Timestamp,
  "check_count": 15
}
```

### Collection: `reports`
```javascript
{
  "phone": "9876543210",
  "category": "scam",
  "description": "Pretended to be bank",
  "reporter_ip": "192.168.1.1",
  "timestamp": Timestamp
}
```

## 🎯 Risk Scoring Algorithm

Risk score is calculated based on:
- **Report Count**: 10 points per report (max 40)
- **Scam Reports**: +30 points
- **Fraud Reports**: +35 points
- **Spam Reports**: +20 points
- **Harassment Reports**: +25 points
- **Blocked Count**: 5 points per block (max 20)

**Risk Levels:**
- 0-29: LOW (Green)
- 30-59: MEDIUM (Orange)
- 60-100: HIGH (Red)

## 🔒 Security Features

1. **Rate Limiting**: Max 5 reports per IP per hour
2. **Phone Validation**: Validates phone number format
3. **IP Logging**: Records reporter IP (for abuse prevention)
4. **API Key Support**: Optional API key authentication
5. **CORS Enabled**: For cross-origin requests

## 🌐 Integrating with Your Website

### Option 1: Embed with iframe
```html
<iframe src="http://localhost:8000/index.html" 
        width="100%" 
        height="800px" 
        frameborder="0">
</iframe>
```

### Option 2: Use API directly
```javascript
// Check a number
async function checkPhoneNumber(phone) {
  const response = await fetch('http://localhost:5000/api/check-number', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ phone })
  });
  
  const data = await response.json();
  return data;
}

// Use it
const result = await checkPhoneNumber('9876543210');
console.log(result.risk.level); // LOW, MEDIUM, or HIGH
```

### Option 3: Copy HTML/CSS/JS
Copy the code from `index.html` and integrate it into your existing website.

## 🚀 Deployment Options

### Option 1: Deploy to Render (Free)

1. Create account at https://render.com
2. Create new Web Service
3. Connect your GitHub repository
4. Set build command: `pip install -r requirements.txt`
5. Set start command: `gunicorn app:app`
6. Add environment variables in Render dashboard
7. Upload `serviceAccountKey.json` content as environment variable
8. Deploy!

### Option 2: Deploy to Google Cloud Run

```bash
# Build container
gcloud builds submit --tag gcr.io/YOUR-PROJECT-ID/phone-checker

# Deploy
gcloud run deploy phone-checker \
  --image gcr.io/YOUR-PROJECT-ID/phone-checker \
  --platform managed \
  --allow-unauthenticated
```

### Option 3: Deploy to PythonAnywhere

1. Upload files to PythonAnywhere
2. Create virtual environment
3. Install requirements
4. Configure WSGI file
5. Reload web app

## 🔧 Production Configuration

### Firebase Security Rules

Update Firestore rules for production:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /phone_numbers/{number} {
      allow read: if true;
      allow write: if request.auth != null;
    }
    match /reports/{report} {
      allow read: if request.auth != null;
      allow create: if true;
    }
  }
}
```

### Environment Variables for Production

```bash
FLASK_ENV=production
FLASK_DEBUG=False
API_KEY=your-strong-production-key
```

### Update API URL in HTML

In `index.html`, change:
```javascript
const API_URL = 'https://your-domain.com/api';
```

## 📱 Mobile App Integration

You can use the same API endpoints in a mobile app:

### Android (Kotlin)
```kotlin
val client = OkHttpClient()
val json = JSONObject()
json.put("phone", "9876543210")

val body = RequestBody.create(
    "application/json".toMediaType(),
    json.toString()
)

val request = Request.Builder()
    .url("https://your-api.com/api/check-number")
    .post(body)
    .build()

client.newCall(request).execute()
```

### iOS (Swift)
```swift
let url = URL(string: "https://your-api.com/api/check-number")!
var request = URLRequest(url: url)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")

let body = ["phone": "9876543210"]
request.httpBody = try? JSONEncoder().encode(body)

URLSession.shared.dataTask(with: request) { data, response, error in
    // Handle response
}.resume()
```

## 🎨 Customization

### Change Colors
Edit the CSS in `index.html`:
```css
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
/* Change to your preferred colors */
```

### Add More Categories
Update the category dropdown in `index.html` and add to `valid_categories` in `app.py`.

### Customize Risk Scoring
Modify the `calculate_risk_score()` function in `app.py` to adjust point values.

## 📊 Monitoring

Check application logs:
```bash
# Development
tail -f app.log

# Production (if using systemd)
journalctl -u phone-checker -f
```

Firebase Console:
- Monitor database reads/writes
- Check for unusual activity
- Review Firestore usage

## 🐛 Troubleshooting

### Firebase Connection Error
```
Error: Could not initialize Firebase
```
**Solution**: Check that `serviceAccountKey.json` is in the correct location and valid.

### CORS Error
```
Access to fetch at 'http://localhost:5000' has been blocked by CORS policy
```
**Solution**: Make sure `flask-cors` is installed and CORS is enabled in `app.py`.

### Phone Number Not Accepted
```
Error: Invalid phone number format
```
**Solution**: Use 10-15 digit numbers without special characters (except +).

### Rate Limit Exceeded
```
Error: Too many reports. Please try again later.
```
**Solution**: Wait 1 hour or use a different network (rate limited by IP).

## 📝 Testing

### Test the API
```bash
# Health check
curl http://localhost:5000/api/health

# Check a number
curl -X POST http://localhost:5000/api/check-number \
  -H "Content-Type: application/json" \
  -d '{"phone":"9876543210"}'

# Report a number
curl -X POST http://localhost:5000/api/report-number \
  -H "Content-Type: application/json" \
  -d '{"phone":"9876543210","category":"scam","description":"Test report"}'

# Get stats
curl http://localhost:5000/api/stats
```

## 🔐 Security Best Practices

1. **Never commit `serviceAccountKey.json`** to Git
2. **Use environment variables** for sensitive data
3. **Enable Firebase security rules** in production
4. **Use HTTPS** in production (not HTTP)
5. **Regularly update dependencies**: `pip install --upgrade -r requirements.txt`
6. **Monitor for abuse** using Firebase Console
7. **Set up rate limiting** on your server/firewall
8. **Keep API keys secret** and rotate regularly

## 🤝 Contributing

To add features:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is open source and available for educational purposes.

## 🆘 Support

For issues or questions:
1. Check the troubleshooting section
2. Review Firebase Console for errors
3. Check application logs
4. Contact your development team

## 🎓 Educational Use

This tool is designed for **cyber education in rural communities**. Use it to:
- Teach about phone scams
- Demonstrate community-based safety
- Build awareness about cyber threats
- Empower users to protect themselves

## 📈 Future Enhancements

Potential features to add:
- SMS notifications for high-risk numbers
- Integration with government databases
- Machine learning for scam pattern detection
- Multi-language support (Hindi, regional languages)
- WhatsApp integration
- Voice call analysis
- Bulk number checking
- Export reports feature
- Admin dashboard

## 🌏 Localization for Rural India

### Hindi Translation Support
Add Hindi labels and messages for better accessibility in rural areas.

### SMS Gateway Integration
Enable SMS-based checking for users without internet:
```
Send: CHECK 9876543210 to 56070
Reply: RISK: HIGH - Reported as scam
```

### USSD Support
Implement USSD codes for feature phone users:
```
Dial: *123*9876543210#
```

## 📞 Contact

For support in rural implementation:
- Document use cases
- Gather feedback
- Track impact metrics
- Share success stories

---

**Remember**: The goal is to protect rural communities from phone scams and cyber fraud through education and technology! 🛡️

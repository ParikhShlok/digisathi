from flask import Flask, request, jsonify
from flask_cors import CORS
import firebase_admin
from firebase_admin import credentials, firestore, initialize_app
import re
from datetime import datetime, timedelta
import os
from functools import wraps

app = Flask(__name__)
CORS(app)  # Enable CORS for website integration

# Initialize Firebase
try:
    # For local development, use service account key
    if os.path.exists('serviceAccountKey.json'):
        cred = credentials.Certificate('serviceAccountKey.json')
        firebase_admin.initialize_app(cred)
    else:
        # For production, use default credentials
        firebase_admin.initialize_app()
    
    db = firestore.client()
    print("Firebase initialized successfully")
except Exception as e:
    print(f"Error initializing Firebase: {e}")
    db = None

# Phone number validation
def validate_phone_number(phone):
    """Validate and clean phone number"""
    # Remove all non-digit characters
    cleaned = re.sub(r'\D', '', phone)
    
    # Check if it's a valid length (10-15 digits)
    if len(cleaned) < 10 or len(cleaned) > 15:
        return None
    
    return cleaned

# Risk calculation
def calculate_risk_score(phone_data):
    """Calculate risk score based on various factors"""
    score = 0
    risk_factors = []
    
    # Check report count
    report_count = phone_data.get('report_count', 0)
    if report_count > 0:
        score += min(report_count * 10, 40)  # Max 40 points from reports
        risk_factors.append(f"{report_count} user report(s)")
    
    # Check report categories
    categories = phone_data.get('categories', {})
    if categories:
        if categories.get('scam', 0) > 0:
            score += 30
            risk_factors.append("Reported as scam")
        if categories.get('spam', 0) > 0:
            score += 20
            risk_factors.append("Reported as spam")
        if categories.get('fraud', 0) > 0:
            score += 35
            risk_factors.append("Reported as fraud")
        if categories.get('harassment', 0) > 0:
            score += 25
            risk_factors.append("Reported as harassment")
    
    # Check blocked count
    blocked_count = phone_data.get('blocked_count', 0)
    if blocked_count > 0:
        score += min(blocked_count * 5, 20)  # Max 20 points from blocks
        risk_factors.append(f"Blocked by {blocked_count} user(s)")
    
    # Determine risk level
    if score >= 60:
        risk_level = "HIGH"
        color = "red"
    elif score >= 30:
        risk_level = "MEDIUM"
        color = "orange"
    else:
        risk_level = "LOW"
        color = "green"
    
    return {
        'score': min(score, 100),  # Cap at 100
        'level': risk_level,
        'color': color,
        'factors': risk_factors
    }

# API Authentication (simple API key)
def require_api_key(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        api_key = request.headers.get('X-API-Key')
        # In production, use environment variable
        valid_key = os.getenv('API_KEY', 'your-secret-api-key-change-this')
        
        if not api_key or api_key != valid_key:
            return jsonify({'error': 'Invalid or missing API key'}), 401
        
        return f(*args, **kwargs)
    return decorated_function

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'ok',
        'firebase': 'connected' if db else 'disconnected',
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/check-number', methods=['POST'])
def check_number():
    """Check a phone number for risk"""
    try:
        data = request.get_json()
        phone = data.get('phone')
        
        if not phone:
            return jsonify({'error': 'Phone number is required'}), 400
        
        # Validate phone number
        cleaned_phone = validate_phone_number(phone)
        if not cleaned_phone:
            return jsonify({'error': 'Invalid phone number format'}), 400
        
        if not db:
            return jsonify({'error': 'Database not available'}), 500
        
        # Get phone data from Firebase
        phone_ref = db.collection('phone_numbers').document(cleaned_phone)
        phone_doc = phone_ref.get()
        
        if phone_doc.exists:
            phone_data = phone_doc.to_dict()
            risk = calculate_risk_score(phone_data)
            
            # Update last checked timestamp
            phone_ref.update({
                'last_checked': datetime.now(),
                'check_count': firestore.Increment(1)
            })
        else:
            # New number - no reports
            phone_data = {
                'phone': cleaned_phone,
                'report_count': 0,
                'categories': {},
                'blocked_count': 0,
                'first_seen': datetime.now(),
                'last_checked': datetime.now(),
                'check_count': 1
            }
            phone_ref.set(phone_data)
            
            risk = {
                'score': 0,
                'level': 'LOW',
                'color': 'green',
                'factors': []
            }
        
        return jsonify({
            'phone': cleaned_phone,
            'risk': risk,
            'report_count': phone_data.get('report_count', 0),
            'categories': phone_data.get('categories', {}),
            'message': get_risk_message(risk['level'])
        })
    
    except Exception as e:
        print(f"Error in check_number: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/report-number', methods=['POST'])
def report_number():
    """Report a suspicious phone number"""
    try:
        data = request.get_json()
        phone = data.get('phone')
        category = data.get('category', 'spam')  # scam, spam, fraud, harassment
        description = data.get('description', '')
        reporter_ip = request.remote_addr
        
        if not phone:
            return jsonify({'error': 'Phone number is required'}), 400
        
        # Validate phone number
        cleaned_phone = validate_phone_number(phone)
        if not cleaned_phone:
            return jsonify({'error': 'Invalid phone number format'}), 400
        
        # Validate category
        valid_categories = ['scam', 'spam', 'fraud', 'harassment', 'other']
        if category not in valid_categories:
            category = 'other'
        
        if not db:
            return jsonify({'error': 'Database not available'}), 500
        
        # Check rate limiting (max 5 reports per IP per hour)
        reports_ref = db.collection('reports')
        one_hour_ago = datetime.now() - timedelta(hours=1)
        recent_reports = reports_ref.where('reporter_ip', '==', reporter_ip)\
                                    .where('timestamp', '>', one_hour_ago)\
                                    .stream()
        
        if len(list(recent_reports)) >= 5:
            return jsonify({'error': 'Too many reports. Please try again later.'}), 429
        
        # Add report to reports collection
        report_data = {
            'phone': cleaned_phone,
            'category': category,
            'description': description,
            'reporter_ip': reporter_ip,
            'timestamp': datetime.now()
        }
        reports_ref.add(report_data)
        
        # Update phone number document
        phone_ref = db.collection('phone_numbers').document(cleaned_phone)
        phone_doc = phone_ref.get()
        
        if phone_doc.exists:
            # Update existing record
            phone_ref.update({
                'report_count': firestore.Increment(1),
                f'categories.{category}': firestore.Increment(1),
                'last_reported': datetime.now()
            })
        else:
            # Create new record
            phone_ref.set({
                'phone': cleaned_phone,
                'report_count': 1,
                'categories': {category: 1},
                'blocked_count': 0,
                'first_seen': datetime.now(),
                'last_reported': datetime.now(),
                'check_count': 0
            })
        
        return jsonify({
            'success': True,
            'message': 'Report submitted successfully',
            'phone': cleaned_phone
        })
    
    except Exception as e:
        print(f"Error in report_number: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/block-number', methods=['POST'])
def block_number():
    """Mark a number as blocked by user"""
    try:
        data = request.get_json()
        phone = data.get('phone')
        
        if not phone:
            return jsonify({'error': 'Phone number is required'}), 400
        
        cleaned_phone = validate_phone_number(phone)
        if not cleaned_phone:
            return jsonify({'error': 'Invalid phone number format'}), 400
        
        if not db:
            return jsonify({'error': 'Database not available'}), 500
        
        # Update blocked count
        phone_ref = db.collection('phone_numbers').document(cleaned_phone)
        phone_doc = phone_ref.get()
        
        if phone_doc.exists:
            phone_ref.update({
                'blocked_count': firestore.Increment(1)
            })
        else:
            phone_ref.set({
                'phone': cleaned_phone,
                'report_count': 0,
                'categories': {},
                'blocked_count': 1,
                'first_seen': datetime.now()
            })
        
        return jsonify({
            'success': True,
            'message': 'Number marked as blocked'
        })
    
    except Exception as e:
        print(f"Error in block_number: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Get overall statistics"""
    try:
        if not db:
            return jsonify({'error': 'Database not available'}), 500
        
        # Get total phone numbers tracked
        phones_ref = db.collection('phone_numbers')
        total_phones = len(list(phones_ref.stream()))
        
        # Get total reports
        reports_ref = db.collection('reports')
        total_reports = len(list(reports_ref.stream()))
        
        # Get high risk numbers (score >= 60)
        high_risk_count = 0
        for phone_doc in phones_ref.stream():
            phone_data = phone_doc.to_dict()
            risk = calculate_risk_score(phone_data)
            if risk['level'] == 'HIGH':
                high_risk_count += 1
        
        return jsonify({
            'total_numbers_tracked': total_phones,
            'total_reports': total_reports,
            'high_risk_numbers': high_risk_count,
            'timestamp': datetime.now().isoformat()
        })
    
    except Exception as e:
        print(f"Error in get_stats: {e}")
        return jsonify({'error': str(e)}), 500

def get_risk_message(risk_level):
    """Get user-friendly message based on risk level"""
    messages = {
        'LOW': '✅ This number appears safe. No reports found.',
        'MEDIUM': '⚠️ Caution advised. This number has some reports.',
        'HIGH': '🚨 High Risk! Multiple users have reported this number as suspicious.'
    }
    return messages.get(risk_level, 'Unknown risk level')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)


***

## CODE_GUIDE.md

```markdown
# PhishGuard Code Guide

This document explains the internal architecture of PhishGuard to help you read and extend the code.

---

## 1. High-level flow

When a user submits the form on `/`:

1. `app.py` receives the form data on POST.
2. It redirects to `/analyze` with inputs passed as URL parameters.
3. `/analyze`:
   - Calls the individual analyzer modules:
     - `url_analyzer` (URL string)
     - `domain_checker` (WHOIS for URL domain)
     - `content_analyzer` (message text)
     - `sender_analyzer` (From / Reply‑To / Subject)
     - `attachment_analyzer` (filenames)
   - Passes all feature dictionaries into `risk_engine.compute_risk_score`.
   - Logs the scan to SQLite.
   - Renders `result.html` with all calculated data.

---

## 2. app.py

### 2.1 Flask setup and database

- Creates a Flask app instance.
- Uses a `get_db()` helper with `g` (Flask context) to manage a single SQLite connection per request.
- `init_db()` creates the `scans` table if it does not exist with fields:
  - `id`, `input_type`, `url`, `message`, `from_header`, `subject`, `attachments`, `risk_score`, `risk_level`, `timestamp`.

### 2.2 Logging scans

`log_scan(...)` inserts one row into the `scans` table with all relevant inputs and the final risk score/level.

---

### 2.3 Routes

#### `/` (index)

- Handles:
  - **GET**: show the main form.
  - **POST**: read all fields:
    - `url_input`
    - `text_input`
    - `from_input`
    - `reply_to_input`
    - `subject_input`
    - `attachments_input`
  - If all fields are empty, shows an error.
  - Otherwise, redirects to `/analyze` with those values as query parameters.

#### `/analyze`

- Reads all parameters from `request.args`.
- Initializes result dicts for each analyzer.
- Conditionally calls:
  - `analyze_url` if URL is given.
  - `analyze_domain` if URL yields a valid domain.
  - `analyze_content` if text is given.
  - `analyze_sender` if any header field is given.
  - `analyze_attachments` if attachment names are given.
- Calls `compute_risk_score` with:
  - `url_features`
  - `domain_features`
  - `content_results`
  - `sender_results`
  - `attachment_results`
- Combines reasons from:
  - individual analyzers
  - risk engine
- Determines a combined `input_type` string (e.g., `"url+text+headers+attachments"`).
- Calls `log_scan(...)`.
- Builds safety recommendations based on risk level.
- Renders `result.html` with all data.

#### `/admin/scans`

- Simple SELECT query ordered by `id DESC` to show the last scans.
- Renders `admin_scans.html`.

---

## 3. analyzer/url_analyzer.py

Key functions:

- `is_ip_address(host)`:
  - Regex + numeric check to see if hostname is IPv4 IP address (e.g. `192.168.1.10`).
- `count_subdomains(host)`:
  - Counts parts beyond the main domain (e.g., `a.b.example.com` → 2).
- `is_shortened_url(netloc)`:
  - Checks against a hard‑coded list of known URL shortener domains.
- `analyze_url(raw_url)`:
  - Uses `urllib.parse.urlparse`.
  - Returns:
    - `features`: dictionary of booleans and numbers:
      - `is_ip_url`, `url_length`, `uses_https`,
        `has_at_symbol`, `has_double_slash_in_path`,
        `has_dash_in_domain`, `subdomain_count`, `is_shortened`
    - `reasons`: human‑readable strings explaining what was detected.

---

## 4. analyzer/domain_checker.py

- Uses `whois.whois(domain)` from the `python-whois` library.
- `_normalize_to_datetime` handles WHOIS fields that might be:
  - single `datetime`
  - list of `datetime`
  - `None`
- `get_domain_age_days(domain)`:
  - Returns age in days or `None` if not available.
- `analyze_domain(domain)`:
  - Returns:
    - `features`:
      - `domain_age_days`
      - `is_new_domain` (True if < 365 days)
      - `whois_available`
    - `reasons`:
      - explanatory strings, especially when WHOIS is missing or the domain is new.

---

## 5. analyzer/content_analyzer.py

- `PHISHING_KEYWORDS`: static list of phishing‑related phrases.
- `_normalize_text(text)`:
  - Lowercases and collapses whitespace.
- `analyze_content(text)`:
  - Counts occurrences of each keyword via `str.count`.
  - Produces:
    - `keyword_counts`
    - `total_matches`
    - `reasons`:
      - e.g., “Message contains common phishing-related keywords.”

---

## 6. analyzer/sender_analyzer.py

- Targets email headers, not SMTP protocols.
- `parse_email_address(raw)`:
  - Uses a simple regex to extract an email address from a header line.
- `get_domain(email)`:
  - Returns the domain part after `@`.
- `analyze_sender(from_field, reply_to_field, subject)`:
  - Extracts `from_email`, `reply_to_email`, and their domains.
  - Flags:
    - Use of known free‑mail providers (gmail.com, yahoo.com, etc.).
    - Mismatch between From and Reply‑To domains.
    - Brand‑like words in the subject paired with free‑mail senders.
  - Returns:
    - `features`: structured sender info and flags.
    - `reasons`: explanatory strings.
    - `risk_points`: integer to add to overall score.

---

## 7. analyzer/attachment_analyzer.py

- Works only on **filenames**, not file contents.
- `RISKY_EXTENSIONS` and `ARCHIVE_EXTENSIONS` define sets of risky and archive suffixes.
- `_get_extension(filename)`:
  - Returns the last extension (e.g., `.exe`).
- `analyze_attachments(raw_input)`:
  - Splits by newline and comma into a clean list.
  - Checks for:
    - Double extensions (like `invoice.pdf.exe`).
    - Directly risky extensions (like `.exe`, `.js`, `.vbs`).
    - Archives with generic / urgent names.
  - Returns:
    - `attachments`: the normalized list of names.
    - `reasons`: list of human explanations.
    - `risky_count`: how many attachments triggered something.
    - `risk_points`: total risk points from attachments.

---

## 8. analyzer/risk_engine.py

- Central function: `compute_risk_score(url_features, domain_features, content_features, sender_data, attachment_data)`.
- Starts `score = 0` and a `reasons` list.
- URL scoring:
  - IP URLs, no HTTPS, `@`, `//` in path, `-` in domain, many subdomains, long URLs, shorteners.
- Domain scoring:
  - Missing WHOIS → small penalty.
  - New domain (< 1 year) → larger penalty.
- Content scoring:
  - Adds up to 30 points based on keyword frequency.
- Sender scoring:
  - Adds `sender_data["risk_points"]` if > 0 and notes it in reasons.
- Attachment scoring:
  - Adds `attachment_data["risk_points"]` if > 0 and notes how many suspicious attachments.
- Deduplicates reasons while preserving order.
- Maps final score to:
  - `"Low Risk"`, `"Medium Risk"`, or `"High Risk"`.

---

## 9. Templates

### index.html

- HTML form with fields for:
  - URL
  - Message text
  - From
  - Reply‑To
  - Subject
  - Attachment names
- Shows an error message if the user submits with all fields empty.

### result.html

- Displays:
  - Summary card: risk level and score.
  - Input recap (URL and/or message).
  - Reasons list.
  - URL features table (if URL provided).
  - Domain information table (if WHOIS data is available).
  - Content analysis (keyword counts).
  - Sender analysis table (if headers were provided).
  - Attachment analysis list (if filenames were provided).
  - Safety recommendations list.

### admin_scans.html

- Simple table of logs from SQLite:
  - Type, URL, message (truncated), score, level, time.
- Useful for testing, demos, and learning.

---

## 10. How to extend the code

A few easy extension points:

- Add more keywords or patterns in `PHISHING_KEYWORDS`.
- Tune risk weights in `risk_engine.py`.
- Add more risky file types or naming rules in `attachment_analyzer.py`.
- Add educational explanation snippets per rule (e.g., map each reason to a “What this means” section).

Because each analyzer is a separate module, you can extend functionality without changing the core application flow.

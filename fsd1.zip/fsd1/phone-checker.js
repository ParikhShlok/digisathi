/**
 * Phone Risk Checker - JavaScript Integration Library
 * Easy integration with your existing website
 */

class PhoneRiskChecker {
    constructor(apiUrl = 'http://localhost:5000/api') {
        this.apiUrl = apiUrl;
    }

    /**
     * Check if a phone number is risky
     * @param {string} phone - Phone number to check
     * @returns {Promise} - Risk assessment data
     */
    async checkNumber(phone) {
        try {
            const response = await fetch(`${this.apiUrl}/check-number`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ phone })
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.error || 'Failed to check number');
            }

            return await response.json();
        } catch (error) {
            console.error('Error checking number:', error);
            throw error;
        }
    }

    /**
     * Report a suspicious phone number
     * @param {string} phone - Phone number to report
     * @param {string} category - Type of issue (scam, spam, fraud, harassment, other)
     * @param {string} description - Optional description
     * @returns {Promise} - Report submission result
     */
    async reportNumber(phone, category = 'spam', description = '') {
        try {
            const response = await fetch(`${this.apiUrl}/report-number`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ phone, category, description })
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.error || 'Failed to report number');
            }

            return await response.json();
        } catch (error) {
            console.error('Error reporting number:', error);
            throw error;
        }
    }

    /**
     * Mark a number as blocked
     * @param {string} phone - Phone number to block
     * @returns {Promise} - Block result
     */
    async blockNumber(phone) {
        try {
            const response = await fetch(`${this.apiUrl}/block-number`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ phone })
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.error || 'Failed to block number');
            }

            return await response.json();
        } catch (error) {
            console.error('Error blocking number:', error);
            throw error;
        }
    }

    /**
     * Get system statistics
     * @returns {Promise} - Statistics data
     */
    async getStats() {
        try {
            const response = await fetch(`${this.apiUrl}/stats`);

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.error || 'Failed to get stats');
            }

            return await response.json();
        } catch (error) {
            console.error('Error getting stats:', error);
            throw error;
        }
    }

    /**
     * Get risk badge HTML for display
     * @param {Object} riskData - Risk data from checkNumber()
     * @returns {string} - HTML badge
     */
    getRiskBadge(riskData) {
        const colors = {
            'LOW': '#28a745',
            'MEDIUM': '#ffc107',
            'HIGH': '#dc3545'
        };

        const color = colors[riskData.risk.level] || '#6c757d';

        return `
            <div style="
                display: inline-block;
                padding: 8px 16px;
                background: ${color};
                color: white;
                border-radius: 20px;
                font-weight: bold;
                font-size: 14px;
            ">
                ${riskData.risk.level} RISK (${riskData.risk.score}/100)
            </div>
        `;
    }

    /**
     * Create a simple widget for checking numbers
     * @param {string} containerId - ID of container element
     */
    createWidget(containerId) {
        const container = document.getElementById(containerId);
        if (!container) {
            console.error(`Container #${containerId} not found`);
            return;
        }

        container.innerHTML = `
            <div style="
                background: white;
                padding: 30px;
                border-radius: 15px;
                box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                max-width: 500px;
                margin: 0 auto;
            ">
                <h2 style="margin-bottom: 20px; color: #333;">
                    📱 Check Phone Number Safety
                </h2>
                
                <input 
                    type="tel" 
                    id="phone-input-${containerId}" 
                    placeholder="Enter phone number"
                    style="
                        width: 100%;
                        padding: 12px;
                        border: 2px solid #ddd;
                        border-radius: 8px;
                        font-size: 16px;
                        margin-bottom: 15px;
                    "
                />
                
                <button 
                    id="check-btn-${containerId}"
                    style="
                        width: 100%;
                        padding: 12px;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        color: white;
                        border: none;
                        border-radius: 8px;
                        font-size: 16px;
                        font-weight: bold;
                        cursor: pointer;
                    "
                >
                    Check Number
                </button>
                
                <div id="result-${containerId}" style="margin-top: 20px;"></div>
            </div>
        `;

        // Add event listener
        const checkBtn = document.getElementById(`check-btn-${containerId}`);
        const phoneInput = document.getElementById(`phone-input-${containerId}`);
        const resultDiv = document.getElementById(`result-${containerId}`);

        checkBtn.addEventListener('click', async () => {
            const phone = phoneInput.value.trim();
            
            if (!phone) {
                resultDiv.innerHTML = `
                    <div style="padding: 15px; background: #f8d7da; border-radius: 8px; color: #721c24;">
                        Please enter a phone number
                    </div>
                `;
                return;
            }

            checkBtn.textContent = 'Checking...';
            checkBtn.disabled = true;

            try {
                const data = await this.checkNumber(phone);
                
                resultDiv.innerHTML = `
                    <div style="
                        padding: 20px;
                        background: ${data.risk.color === 'green' ? '#d4edda' : 
                                     data.risk.color === 'orange' ? '#fff3cd' : '#f8d7da'};
                        border-radius: 8px;
                        border-left: 4px solid ${data.risk.color};
                    ">
                        <h3 style="margin-bottom: 10px;">
                            ${data.message}
                        </h3>
                        <div style="font-size: 32px; font-weight: bold; text-align: center; margin: 15px 0;">
                            ${data.risk.score}/100
                        </div>
                        <div style="font-size: 14px; color: #666;">
                            ${data.report_count} user report(s)
                        </div>
                    </div>
                `;
            } catch (error) {
                resultDiv.innerHTML = `
                    <div style="padding: 15px; background: #f8d7da; border-radius: 8px; color: #721c24;">
                        Error: ${error.message}
                    </div>
                `;
            } finally {
                checkBtn.textContent = 'Check Number';
                checkBtn.disabled = false;
            }
        });
    }
}

// Usage Examples:

/*
// Example 1: Simple check
const checker = new PhoneRiskChecker('https://your-api.com/api');

const result = await checker.checkNumber('9876543210');
console.log(result.risk.level); // LOW, MEDIUM, or HIGH


// Example 2: Add to existing form
document.getElementById('myForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const phone = document.getElementById('phoneNumber').value;
    const checker = new PhoneRiskChecker();
    
    try {
        const result = await checker.checkNumber(phone);
        
        if (result.risk.level === 'HIGH') {
            alert('Warning: This number has been reported as high risk!');
        } else {
            // Proceed with form submission
            submitForm();
        }
    } catch (error) {
        console.error('Risk check failed:', error);
        // Still allow form submission if check fails
        submitForm();
    }
});


// Example 3: Create a widget
const checker = new PhoneRiskChecker('http://localhost:5000/api');
checker.createWidget('phone-checker-container');


// Example 4: Display risk badge
const checker = new PhoneRiskChecker();
const result = await checker.checkNumber('9876543210');
document.getElementById('badge').innerHTML = checker.getRiskBadge(result);


// Example 5: Report a number
const checker = new PhoneRiskChecker();
await checker.reportNumber('9876543210', 'scam', 'Pretended to be bank');


// Example 6: Get statistics
const checker = new PhoneRiskChecker();
const stats = await checker.getStats();
console.log(`Total reports: ${stats.total_reports}`);


// Example 7: WordPress integration
function addPhoneChecker() {
    // Add this to your WordPress theme
    const checker = new PhoneRiskChecker('https://your-domain.com/api');
    
    // Find all phone number inputs
    document.querySelectorAll('input[type="tel"]').forEach(input => {
        // Add check button next to input
        const btn = document.createElement('button');
        btn.textContent = '🔍 Check';
        btn.onclick = async () => {
            const result = await checker.checkNumber(input.value);
            alert(`Risk: ${result.risk.level}`);
        };
        input.parentNode.insertBefore(btn, input.nextSibling);
    });
}


// Example 8: React Component
function PhoneChecker() {
    const [phone, setPhone] = useState('');
    const [result, setResult] = useState(null);
    const checker = new PhoneRiskChecker();
    
    const handleCheck = async () => {
        try {
            const data = await checker.checkNumber(phone);
            setResult(data);
        } catch (error) {
            alert(error.message);
        }
    };
    
    return (
        <div>
            <input 
                value={phone} 
                onChange={(e) => setPhone(e.target.value)}
                placeholder="Enter phone number"
            />
            <button onClick={handleCheck}>Check</button>
            
            {result && (
                <div style={{color: result.risk.color}}>
                    Risk: {result.risk.level}
                </div>
            )}
        </div>
    );
}
*/

// Export for use in modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PhoneRiskChecker;
}

"""
Test script to verify Phone Risk Checker setup
Run this after setting up Firebase to ensure everything works
"""

import requests
import json

API_URL = "http://localhost:5000/api"

def print_header(text):
    print("\n" + "="*60)
    print(f"  {text}")
    print("="*60)

def test_health_check():
    """Test if server is running"""
    print_header("Testing Health Check")
    try:
        response = requests.get(f"{API_URL}/health")
        data = response.json()
        print(f"Status: {response.status_code}")
        print(f"Response: {json.dumps(data, indent=2)}")
        
        if data.get('status') == 'ok':
            print("✅ Health check passed!")
            return True
        else:
            print("❌ Health check failed!")
            return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_check_number():
    """Test phone number checking"""
    print_header("Testing Phone Number Check")
    
    test_phone = "9876543210"
    try:
        response = requests.post(
            f"{API_URL}/check-number",
            json={"phone": test_phone},
            headers={"Content-Type": "application/json"}
        )
        data = response.json()
        print(f"Status: {response.status_code}")
        print(f"Response: {json.dumps(data, indent=2)}")
        
        if response.status_code == 200:
            print(f"✅ Successfully checked number: {test_phone}")
            print(f"   Risk Level: {data['risk']['level']}")
            print(f"   Risk Score: {data['risk']['score']}/100")
            return True
        else:
            print(f"❌ Failed to check number: {data.get('error')}")
            return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_report_number():
    """Test phone number reporting"""
    print_header("Testing Phone Number Report")
    
    test_phone = "9999999999"  # Different number for testing
    try:
        response = requests.post(
            f"{API_URL}/report-number",
            json={
                "phone": test_phone,
                "category": "scam",
                "description": "Test scam report - automated test"
            },
            headers={"Content-Type": "application/json"}
        )
        data = response.json()
        print(f"Status: {response.status_code}")
        print(f"Response: {json.dumps(data, indent=2)}")
        
        if response.status_code == 200 and data.get('success'):
            print(f"✅ Successfully reported number: {test_phone}")
            return True
        else:
            print(f"❌ Failed to report number: {data.get('error')}")
            return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_check_reported_number():
    """Test checking the number we just reported"""
    print_header("Testing Check After Report")
    
    test_phone = "9999999999"
    try:
        response = requests.post(
            f"{API_URL}/check-number",
            json={"phone": test_phone},
            headers={"Content-Type": "application/json"}
        )
        data = response.json()
        print(f"Status: {response.status_code}")
        print(f"Response: {json.dumps(data, indent=2)}")
        
        if response.status_code == 200:
            report_count = data.get('report_count', 0)
            if report_count > 0:
                print(f"✅ Report verified! Number has {report_count} report(s)")
                print(f"   Risk Level: {data['risk']['level']}")
                return True
            else:
                print("⚠️ No reports found (might be timing issue)")
                return True
        else:
            print(f"❌ Failed to verify report")
            return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_stats():
    """Test statistics endpoint"""
    print_header("Testing Statistics")
    
    try:
        response = requests.get(f"{API_URL}/stats")
        data = response.json()
        print(f"Status: {response.status_code}")
        print(f"Response: {json.dumps(data, indent=2)}")
        
        if response.status_code == 200:
            print("✅ Statistics retrieved successfully!")
            print(f"   Total Numbers: {data.get('total_numbers_tracked', 0)}")
            print(f"   Total Reports: {data.get('total_reports', 0)}")
            print(f"   High Risk: {data.get('high_risk_numbers', 0)}")
            return True
        else:
            print(f"❌ Failed to get statistics")
            return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_invalid_phone():
    """Test with invalid phone number"""
    print_header("Testing Invalid Phone Number")
    
    invalid_phone = "123"  # Too short
    try:
        response = requests.post(
            f"{API_URL}/check-number",
            json={"phone": invalid_phone},
            headers={"Content-Type": "application/json"}
        )
        data = response.json()
        print(f"Status: {response.status_code}")
        print(f"Response: {json.dumps(data, indent=2)}")
        
        if response.status_code == 400:
            print("✅ Invalid phone correctly rejected!")
            return True
        else:
            print("⚠️ Invalid phone should return 400 error")
            return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def run_all_tests():
    """Run all tests"""
    print("\n")
    print("🚀 Starting Phone Risk Checker Tests")
    print("Make sure the Flask server is running on http://localhost:5000")
    print("\n")
    
    input("Press Enter to start testing...")
    
    tests = [
        ("Health Check", test_health_check),
        ("Check Number", test_check_number),
        ("Report Number", test_report_number),
        ("Verify Report", test_check_reported_number),
        ("Statistics", test_stats),
        ("Invalid Phone", test_invalid_phone)
    ]
    
    results = []
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"\n❌ Test '{name}' crashed: {e}")
            results.append((name, False))
    
    # Summary
    print_header("Test Summary")
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} - {name}")
    
    print(f"\n{'='*60}")
    print(f"Results: {passed}/{total} tests passed")
    print(f"{'='*60}\n")
    
    if passed == total:
        print("🎉 All tests passed! Your setup is working correctly!")
    else:
        print("⚠️ Some tests failed. Please check the error messages above.")
        print("\nCommon issues:")
        print("1. Flask server not running (run: python app.py)")
        print("2. Firebase not configured (check serviceAccountKey.json)")
        print("3. Wrong API URL (check if server is on port 5000)")

if __name__ == "__main__":
    run_all_tests()

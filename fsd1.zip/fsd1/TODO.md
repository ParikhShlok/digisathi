# TODO: Add Sideways Navbar with Toggler to HTML Files

## Files to Update (excluding main.html):
- [ ] Basicinternetsafety.html (already has side navbar, verify consistency)
- [ ] usepass.html (add toggle button and side navbar)
- [ ] secureweb.html (add toggle button and side navbar)
- [ ] avoidemail.html (replace top navbar with fixed toggle button, update side navbar links)
- [ ] prodata.html (add toggle button and side navbar)
- [ ] avoidscams.html (replace top navbar with fixed toggle button, update side navbar links)
- [ ] howtouseyouphone.html (add toggle button and side navbar)
- [ ] startlearningfree.html (add toggle button and side navbar, remove existing sidebar if needed)

## Navbar Components to Add:
- Fixed toggle button (☰) at top-left
- Offcanvas side navbar with links to:
  - Home (main.html)
  - Strong Passwords (usepass.html)
  - Avoid Emails (avoidemail.html)
  - Protect Data (prodata.html)
  - Secure Websites (secureweb.html)
  - Avoid Scams (avoidscams.html)
  - How to Use Your Phone (howtouseyouphone.html)
  - Start Learning Free (startlearningfree.html)

## CSS to Add:
- .menu-btn { position: fixed; top: 20px; left: 20px; z-index: 1051; }

## Implementation Steps:
1. Update Basicinternetsafety.html to include all links in navbar.
2. Add navbar to usepass.html.
3. Add navbar to secureweb.html.
4. Update avoidemail.html.
5. Add navbar to prodata.html.
6. Update avoidscams.html.
7. Add navbar to howtouseyouphone.html.
8. Add navbar to startlearningfree.html.

# ============================================
# DEPLOYMENT GUIDES FOR VARIOUS PLATFORMS
# ============================================

# ==========================================
# 1. RENDER.COM DEPLOYMENT (FREE TIER)
# ==========================================

# Step 1: Push code to GitHub
# Step 2: Create new Web Service on Render
# Step 3: Use these settings:

Name: phone-risk-checker
Environment: Python 3
Build Command: pip install -r requirements.txt
Start Command: gunicorn app:app --bind 0.0.0.0:$PORT

# Step 4: Add environment variables:
PYTHON_VERSION=3.11.0
API_KEY=your-secure-random-key

# Step 5: Add Firebase credentials as environment variable
# Copy content of serviceAccountKey.json and add as:
GOOGLE_APPLICATION_CREDENTIALS_JSON=<paste-json-content>

# Modify app.py to use JSON from env:
# import os
# import json
# cred_dict = json.loads(os.getenv('GOOGLE_APPLICATION_CREDENTIALS_JSON'))
# cred = credentials.Certificate(cred_dict)


# ==========================================
# 2. HEROKU DEPLOYMENT
# ==========================================

# Create Procfile
web: gunicorn app:app

# Create runtime.txt
python-3.11.0

# Deploy commands:
heroku login
heroku create phone-risk-checker
heroku config:set API_KEY=your-secret-key
# For Firebase, add buildpack:
heroku buildpacks:add heroku/python
git push heroku main


# ==========================================
# 3. GOOGLE CLOUD RUN
# ==========================================

# Create Dockerfile:
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 8080

CMD exec gunicorn --bind :8080 --workers 1 --threads 8 app:app

# Deploy:
gcloud builds submit --tag gcr.io/PROJECT-ID/phone-checker
gcloud run deploy phone-checker \
  --image gcr.io/PROJECT-ID/phone-checker \
  --platform managed \
  --region asia-south1 \
  --allow-unauthenticated


# ==========================================
# 4. PYTHONANYWHERE DEPLOYMENT
# ==========================================

# Step 1: Upload files via Dashboard or Git
# Step 2: Create virtual environment:
mkvirtualenv phone-checker --python=/usr/bin/python3.10
pip install -r requirements.txt

# Step 3: Configure WSGI file (/var/www/username_pythonanywhere_com_wsgi.py):
import sys
import os

project_home = '/home/username/phone-risk-checker'
if project_home not in sys.path:
    sys.path = [project_home] + sys.path

from app import app as application

# Step 4: Set working directory in Web tab
# Step 5: Reload web app


# ==========================================
# 5. AWS EC2 DEPLOYMENT
# ==========================================

# On Ubuntu EC2 instance:

# Install dependencies
sudo apt update
sudo apt install python3-pip nginx

# Clone repository
git clone https://github.com/yourusername/phone-risk-checker
cd phone-risk-checker

# Install Python packages
pip3 install -r requirements.txt

# Install and configure Gunicorn
pip3 install gunicorn

# Create systemd service: /etc/systemd/system/phone-checker.service
[Unit]
Description=Phone Risk Checker
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/phone-risk-checker
Environment="PATH=/home/ubuntu/.local/bin"
ExecStart=/home/ubuntu/.local/bin/gunicorn --workers 3 --bind 0.0.0.0:5000 app:app

[Install]
WantedBy=multi-user.target

# Start service
sudo systemctl start phone-checker
sudo systemctl enable phone-checker

# Configure Nginx: /etc/nginx/sites-available/phone-checker
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}

sudo ln -s /etc/nginx/sites-available/phone-checker /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx


# ==========================================
# 6. DIGITALOCEAN APP PLATFORM
# ==========================================

# Create app.yaml:
name: phone-risk-checker
services:
- name: api
  github:
    repo: yourusername/phone-risk-checker
    branch: main
  build_command: pip install -r requirements.txt
  run_command: gunicorn app:app
  envs:
  - key: API_KEY
    value: your-secret-key
  http_port: 8080


# ==========================================
# 7. VERCEL DEPLOYMENT (Serverless)
# ==========================================

# Create vercel.json:
{
  "builds": [
    {
      "src": "app.py",
      "use": "@vercel/python"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "app.py"
    }
  ]
}

# Deploy:
vercel --prod


# ==========================================
# 8. NETLIFY DEPLOYMENT (Frontend Only)
# ==========================================

# For static frontend, create netlify.toml:
[build]
  publish = "."

[[redirects]]
  from = "/api/*"
  to = "https://your-backend-api.com/api/:splat"
  status = 200


# ==========================================
# PRODUCTION CHECKLIST
# ==========================================

☐ Set FLASK_ENV=production
☐ Set FLASK_DEBUG=False
☐ Generate strong API_KEY
☐ Update API URL in index.html
☐ Set up HTTPS/SSL certificate
☐ Configure Firebase security rules
☐ Enable CORS only for your domain
☐ Set up monitoring/logging
☐ Configure backup for Firebase
☐ Test all endpoints
☐ Add rate limiting at server level
☐ Set up CDN for static files
☐ Configure custom domain
☐ Add Google Analytics (optional)


# ==========================================
# ENVIRONMENT VARIABLES FOR PRODUCTION
# ==========================================

FLASK_ENV=production
FLASK_DEBUG=False
API_KEY=<generate-strong-key>
GOOGLE_APPLICATION_CREDENTIALS=serviceAccountKey.json
# OR
GOOGLE_APPLICATION_CREDENTIALS_JSON=<json-string>


# ==========================================
# HTTPS/SSL SETUP (Let's Encrypt)
# ==========================================

# On server with domain:
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
sudo certbot renew --dry-run  # Test renewal


# ==========================================
# MONITORING SETUP
# ==========================================

# Install logging
pip install python-json-logger

# Add to app.py:
import logging
from pythonjsonlogger import jsonlogger

logHandler = logging.StreamHandler()
formatter = jsonlogger.JsonFormatter()
logHandler.setFormatter(formatter)
app.logger.addHandler(logHandler)
app.logger.setLevel(logging.INFO)


# ==========================================
# BACKUP FIREBASE DATA
# ==========================================

# Automated backup script:
gcloud firestore export gs://your-bucket/backups/$(date +%Y%m%d)


# ==========================================
# PERFORMANCE OPTIMIZATION
# ==========================================

# 1. Enable Gzip compression
pip install flask-compress
from flask_compress import Compress
Compress(app)

# 2. Add caching
pip install flask-caching
from flask_caching import Cache
cache = Cache(app, config={'CACHE_TYPE': 'simple'})

# 3. Use CDN for static files
# Upload index.html, phone-checker.js to CDN

# 4. Enable Firebase offline persistence
# 5. Add service worker for PWA
# 6. Optimize images
# 7. Minify JS/CSS

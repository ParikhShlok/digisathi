# analyzer/sender_analyzer.py
# Simple, passive sender/header trust analysis.
# Works entirely on user-pasted header text; no network access.

import re
from typing import Dict, List


SUSPICIOUS_FREE_MAIL = [
    "gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "proton.me", "protonmail.com"
]

BRAND_HINT_WORDS = [
    "bank", "pay", "paypal", "secure", "support", "service", "verification", "update"
]


def parse_email_address(raw: str) -> str:
    """
    Extract email address from something like:
      'PayPal Support <support@paypal.com>'
      '"ICICI Bank" <no-reply@alerts.icicibank.com>'
    Returns lowercase email or empty string.
    """
    if not raw:
        return ""
    # Use a simple regex rather than full email parser to keep it beginner-friendly.
    match = re.search(r"[\w\.-]+@[\w\.-]+\.\w+", raw)
    return match.group(0).lower() if match else ""


def get_domain(email: str) -> str:
    """
    Extract domain part from email address.
    """
    if "@" not in email:
        return ""
    return email.split("@", 1)[1].lower()


def analyze_sender(from_field: str, reply_to_field: str, subject: str) -> Dict[str, object]:
    """
    Analyze sender information for basic trust indicators.

    Returns:
      - features: dict with fields like:
          - from_email, reply_to_email
          - from_domain, reply_to_domain
          - uses_free_mail
          - domain_mismatch
          - suspicious_brand_words
      - reasons: list of strings
      - risk_points: integer to be added to overall risk score
    """
    reasons: List[str] = []
    features: Dict[str, object] = {
        "from_email": "",
        "reply_to_email": "",
        "from_domain": "",
        "reply_to_domain": "",
        "uses_free_mail": False,
        "domain_mismatch": False,
        "suspicious_brand_words": [],
    }
    risk_points = 0

    from_email = parse_email_address(from_field)
    reply_email = parse_email_address(reply_to_field)
    from_domain = get_domain(from_email)
    reply_domain = get_domain(reply_email)

    features["from_email"] = from_email
    features["reply_to_email"] = reply_email
    features["from_domain"] = from_domain
    features["reply_to_domain"] = reply_domain

    # Free-mail pretending to be brand
    if from_domain in SUSPICIOUS_FREE_MAIL:
        features["uses_free_mail"] = True
        risk_points += 5
        reasons.append(
            "Sender uses a free email provider, which is uncommon for official business communications."
        )

    # From vs Reply-To mismatch
    if from_domain and reply_domain and from_domain != reply_domain:
        features["domain_mismatch"] = True
        risk_points += 10
        reasons.append(
            "From and Reply-To domains differ, which is often used to redirect responses to attackers."
        )

    # Brand-like keywords in subject vs generic/unknown sender
    subject_lower = (subject or "").lower()
    brand_words_found = [
        w for w in BRAND_HINT_WORDS if w in subject_lower
    ]
    features["suspicious_brand_words"] = brand_words_found

    if brand_words_found and from_domain in SUSPICIOUS_FREE_MAIL:
        risk_points += 10
        reasons.append(
            "Subject mentions brands or financial terms but the sender uses a free-mail address."
        )

    return {
        "features": features,
        "reasons": reasons,
        "risk_points": risk_points,
    }

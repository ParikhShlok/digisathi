# analyzer/content_analyzer.py
# Message/email content analysis for phishing indicators.
# Only performs keyword-based analysis; no external requests.

import re
from collections import Counter
from typing import Dict, List

# Simple list of phishing-related keywords and phrases.
PHISHING_KEYWORDS = [
    "urgent",
    "immediately",
    "verify",
    "verification",
    "otp",
    "one time password",
    "reset password",
    "click here",
    "account blocked",
    "account suspended",
    "confirm your account",
    "update your information",
    "login now",
    "security alert",
]


def _normalize_text(text: str) -> str:
    """
    Lowercase text and collapse whitespace for simpler matching.
    """
    return re.sub(r"\s+", " ", text.lower()).strip()


def analyze_content(text: str) -> Dict[str, object]:
    """
    Analyze content for phishing keywords.

    Returns:
      - keyword_counts: dict keyword -> count
      - total_matches: int
      - reasons: list of strings
    """
    normalized = _normalize_text(text)
    keyword_counts: Dict[str, int] = {}

    for kw in PHISHING_KEYWORDS:
        # Simple substring matching; can be replaced by more advanced NLP later.
        count = normalized.count(kw.lower())
        if count > 0:
            keyword_counts[kw] = count

    total_matches = sum(keyword_counts.values())
    reasons: List[str] = []

    if total_matches > 0:
        reasons.append("Message contains common phishing-related keywords or phrases.")
    if total_matches >= 5:
        reasons.append("High frequency of phishing keywords detected in the message.")

    return {
        "keyword_counts": keyword_counts,
        "total_matches": total_matches,
        "reasons": reasons,
    }

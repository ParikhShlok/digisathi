# analyzer/url_analyzer.py
# URL analysis utilities for PhishGuard.
# This module implements simple, defensive checks on URLs only.
# It does NOT perform any active scanning or exploitation.

import re
from urllib.parse import urlparse

# Common URL shortener domains (extendable).
URL_SHORTENERS = [
    "bit.ly", "tinyurl.com", "goo.gl", "t.co", "ow.ly",
    "is.gd", "buff.ly", "cutt.ly", "bit.do"
]


def is_ip_address(host: str) -> bool:
    """
    Check if the host part of the URL is an IPv4 address.
    Using a simple regex and range validation.
    """
    ip_pattern = re.compile(r"^(?:\d{1,3}\.){3}\d{1,3}$")
    if not ip_pattern.match(host):
        return False

    parts = host.split(".")
    return all(0 <= int(part) <= 255 for part in parts)


def count_subdomains(host: str) -> int:
    """
    Count the number of subdomains.
    Example:
      - "example.com" -> 0
      - "mail.example.com" -> 1
      - "a.b.example.com" -> 2
    """
    if not host:
        return 0

    parts = host.split(".")
    if len(parts) <= 2:
        return 0
    return len(parts) - 2


def is_shortened_url(netloc: str) -> bool:
    """
    Check whether the domain is a known URL shortener.
    Comparison is done in lowercase and with basic matching.
    """
    domain = netloc.lower()
    return any(domain == s or domain.endswith("." + s) for s in URL_SHORTENERS)


def analyze_url(raw_url: str) -> dict:
    """
    Perform static rule-based analysis on a URL string.

    Returns a dict with:
      - features: dict of detected properties
      - reasons: list of human-readable reasons
    """
    features = {
        "is_ip_url": False,
        "url_length": len(raw_url),
        "uses_https": False,
        "has_at_symbol": False,
        "has_double_slash_in_path": False,
        "has_dash_in_domain": False,
        "subdomain_count": 0,
        "is_shortened": False,
    }
    reasons = []

    try:
        parsed = urlparse(raw_url if "://" in raw_url else "http://" + raw_url)
    except Exception:
        reasons.append("URL could not be parsed.")
        return {"features": features, "reasons": reasons}

    host = parsed.hostname or ""
    netloc = parsed.netloc or ""

    # IP-based URL
    if is_ip_address(host):
        features["is_ip_url"] = True
        reasons.append("URL uses an IP address instead of a domain name.")

    # HTTPS check
    if parsed.scheme.lower() == "https":
        features["uses_https"] = True
    else:
        reasons.append("URL does not use HTTPS (secure HTTP).")

    # '@' symbol in URL
    if "@" in raw_url:
        features["has_at_symbol"] = True
        reasons.append("URL contains '@', which can hide the real destination.")

    # '//' in the path (beyond the protocol part)
    path_and_query = parsed.path + parsed.query
    if "//" in path_and_query:
        features["has_double_slash_in_path"] = True
        reasons.append("URL path contains '//' which is unusual and suspicious.")

    # '-' in domain
    if "-" in host:
        features["has_dash_in_domain"] = True
        reasons.append("Domain contains '-', which can be used in look-alike domains.")

    # URL shortener
    if is_shortened_url(netloc):
        features["is_shortened"] = True
        reasons.append("URL uses a known URL shortener, often used to hide real destinations.")

    # Subdomain count
    sub_count = count_subdomains(host)
    features["subdomain_count"] = sub_count
    if sub_count >= 3:
        reasons.append("URL has many subdomains, which can be a sign of phishing.")

    # URL length heuristics
    if len(raw_url) > 80:
        reasons.append("URL is unusually long, which can indicate obfuscation.")

    return {"features": features, "reasons": reasons}

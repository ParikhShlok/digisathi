# analyzer/domain_checker.py
# Domain WHOIS analysis for PhishGuard.
# Only performs passive WHOIS lookups; no active scanning.

import datetime
from typing import Optional, Tuple

import whois  # python-whois library [web:4]


def _normalize_to_datetime(value) -> Optional[datetime.datetime]:
    """
    Ensure WHOIS date fields are converted to a single datetime or None.
    WHOIS data may return a list of dates; in that case, choose the earliest.
    """
    if value is None:
        return None
    if isinstance(value, list):
        # Filter out Nones and return earliest
        dates = [v for v in value if isinstance(v, datetime.datetime)]
        return min(dates) if dates else None
    if isinstance(value, datetime.datetime):
        return value
    return None


def get_domain_age_days(domain: str) -> Optional[int]:
    """
    Fetch WHOIS data and compute domain age in days.
    Returns None if data is missing or cannot be parsed.
    """
    try:
        data = whois.whois(domain)
    except Exception:
        # WHOIS data may be unavailable or the domain invalid.
        return None

    creation_date = _normalize_to_datetime(data.creation_date)
    if not creation_date:
        return None

    today = datetime.datetime.utcnow()
    age = today - creation_date
    return age.days


def analyze_domain(domain: str) -> Tuple[dict, list]:
    """
    Analyze domain WHOIS information.

    Returns (features_dict, reasons_list).
    features:
      - domain_age_days: int or None
      - is_new_domain: bool
      - whois_available: bool
    """
    features = {
        "domain_age_days": None,
        "is_new_domain": False,
        "whois_available": False,
    }
    reasons = []

    age_days = get_domain_age_days(domain)
    if age_days is None:
        reasons.append("WHOIS data is unavailable or incomplete; domain age could not be determined.")
        return features, reasons

    features["whois_available"] = True
    features["domain_age_days"] = age_days

    if age_days < 365:
        features["is_new_domain"] = True
        reasons.append("Domain is less than 1 year old, which is common for phishing campaigns.")

    return features, reasons

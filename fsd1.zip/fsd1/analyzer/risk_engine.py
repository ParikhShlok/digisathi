# analyzer/risk_engine.py
# Risk scoring engine combining URL, domain, content, sender, and attachment features.
# Scores are heuristic and only for educational/defensive purposes.

from typing import Dict, List, Tuple


def compute_risk_score(
    url_features: Dict,
    domain_features: Dict,
    content_features: Dict,
    sender_data: Dict,
    attachment_data: Dict,
) -> Tuple[int, str, List[str]]:
    """
    Combine features into a single risk score and risk level.

    Risk levels:
      0–30   -> Low Risk
      31–60  -> Medium Risk
      61+    -> High Risk
    """
    score = 0
    reasons: List[str] = []

    # URL-based scoring
    if url_features.get("is_ip_url"):
        score += 15
        reasons.append("URL uses an IP address instead of a domain (uncommon for legitimate sites).")

    if not url_features.get("uses_https"):
        score += 10
        reasons.append("Connection is not HTTPS, which reduces confidentiality and integrity.")

    if url_features.get("has_at_symbol"):
        score += 10
        reasons.append("URL uses '@' which may hide the real destination.")

    if url_features.get("has_double_slash_in_path"):
        score += 5
        reasons.append("Unusual '//' in URL path, sometimes used in obfuscation.")

    if url_features.get("has_dash_in_domain"):
        score += 5
        reasons.append("Domain contains '-', sometimes used to mimic legitimate brands.")

    sub_count = url_features.get("subdomain_count", 0)
    if sub_count >= 3:
        score += 10
        reasons.append("URL has many subdomains, which can be used to confuse users.")

    url_length = url_features.get("url_length", 0)
    if url_length > 80:
        score += 5
        reasons.append("URL is unusually long, which can indicate obfuscation.")
    elif url_length > 120:
        score += 10

    if url_features.get("is_shortened"):
        score += 15
        reasons.append("Use of URL shortener hides the final destination.")

    # Domain-based scoring
    if domain_features:
        if not domain_features.get("whois_available", False):
            score += 5
            reasons.append("Domain WHOIS information is missing or incomplete.")
        else:
            if domain_features.get("is_new_domain"):
                score += 15
                reasons.append("Domain is newly registered (< 1 year), common in phishing.")

    # Content-based scoring
    total_matches = content_features.get("total_matches", 0)
    if total_matches > 0:
        score += min(5 * total_matches, 30)  # Cap content influence.
        reasons.append(
            f"Message contains {total_matches} phishing-related keyword occurrence(s)."
        )

    # Sender-based scoring (new)
    if sender_data:
        sender_risk_points = sender_data.get("risk_points", 0)
        if sender_risk_points > 0:
            score += sender_risk_points
            reasons.append(
                f"Sender/header analysis added {sender_risk_points} risk points based on mismatches or free-mail usage."
            )

    # Attachment-based scoring (new)
    if attachment_data:
        attachment_risk_points = attachment_data.get("risk_points", 0)
        risky_count = attachment_data.get("risky_count", 0)
        if attachment_risk_points > 0:
            score += attachment_risk_points
            reasons.append(
                f"Attachment analysis added {attachment_risk_points} risk points from {risky_count} suspicious attachment(s)."
            )

    # Deduplicate reasons while preserving order.
    unique_reasons: List[str] = []
    seen = set()
    for r in reasons:
        if r not in seen:
            seen.add(r)
            unique_reasons.append(r)

    # Classify risk level
    if score <= 30:
        risk_level = "Low Risk"
    elif score <= 60:
        risk_level = "Medium Risk"
    else:
        risk_level = "High Risk"

    return score, risk_level, unique_reasons

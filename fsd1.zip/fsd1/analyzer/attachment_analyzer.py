# analyzer/attachment_analyzer.py
# Passive analysis of attachment filenames for risky patterns.

from typing import Dict, List


RISKY_EXTENSIONS = {
    ".exe", ".bat", ".cmd", ".js", ".vbs", ".ps1", ".scr", ".jar", ".msi"
}

ARCHIVE_EXTENSIONS = {
    ".zip", ".rar", ".7z"
}


def _get_extension(filename: str) -> str:
    """
    Return the lowercase extension, including dot (e.g. '.exe'), or ''.
    """
    filename = filename.strip().lower()
    if "." not in filename:
        return ""
    return "." + filename.split(".")[-1]


def analyze_attachments(raw_input: str) -> Dict[str, object]:
    """
    Analyze a list of attachment names, separated by commas or newlines.

    Returns:
      - attachments: cleaned list of names
      - reasons: list of strings
      - risky_count: int
      - risk_points: int
    """
    if not raw_input:
        return {
            "attachments": [],
            "reasons": [],
            "risky_count": 0,
            "risk_points": 0,
        }

    # Split by comma or newline
    raw_items = [item.strip() for item in raw_input.replace("\r", "\n").split("\n")]
    attachments = []
    for item in raw_items:
        for part in item.split(","):
            name = part.strip()
            if name:
                attachments.append(name)

    reasons: List[str] = []
    risky_count = 0
    risk_points = 0

    for name in attachments:
        lower_name = name.lower()
        ext = _get_extension(lower_name)

        # Double extension check: e.g., "invoice.pdf.exe"
        parts = lower_name.split(".")
        if len(parts) >= 3:
            # Has at least two dots; if last ext is risky and previous looks like document, flag it
            last_ext = "." + parts[-1]
            prev_ext = "." + parts[-2]
            if last_ext in RISKY_EXTENSIONS and prev_ext in {".pdf", ".doc", ".docx", ".xls", ".xlsx"}:
                risky_count += 1
                risk_points += 10
                reasons.append(
                    f"Attachment '{name}' has a double extension ({prev_ext}{last_ext}), often used to hide executables."
                )
                continue  # avoid double counting below

        # Directly risky extension
        if ext in RISKY_EXTENSIONS:
            risky_count += 1
            risk_points += 7
            reasons.append(
                f"Attachment '{name}' has executable or script extension ({ext}), which can run code."
            )

        # Archive with generic or urgent name
        elif ext in ARCHIVE_EXTENSIONS and any(
            keyword in lower_name for keyword in ["urgent", "invoice", "payment", "account", "password"]
        ):
            risky_count += 1
            risk_points += 5
            reasons.append(
                f"Archive attachment '{name}' uses generic/urgent naming, which attackers often use to lure users."
            )

    return {
        "attachments": attachments,
        "reasons": reasons,
        "risky_count": risky_count,
        "risk_points": risk_points,
    }

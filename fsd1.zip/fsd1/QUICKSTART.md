# 🚀 Quick Start Guide - Phone Risk Checker for Rural Cyber Education

## 📱 What You're Building

A community-powered phone number checker that helps rural people identify scam calls. Users can:
1. Check if a phone number has been reported as suspicious
2. Report scam/spam numbers to help others
3. Learn about phone scams and cyber safety

## ⚡ 5-Minute Setup (Local Development)

### Prerequisites
- Python 3.8+ installed
- Web browser
- 15 minutes of your time

### Step 1: Get Firebase Ready (5 minutes)

1. Go to https://console.firebase.google.com/
2. Click "Add project"
3. Name it "phone-checker" → Continue
4. Disable Google Analytics → Create project
5. Once created, go to "Build" → "Firestore Database"
6. Click "Create database"
7. Select "Test mode" → Next
8. Choose location closest to India (asia-south1) → Enable
9. Go to Project Settings (⚙️) → Service accounts
10. Click "Generate new private key" → Download JSON
11. Rename the downloaded file to `serviceAccountKey.json`
12. Put it in the phone-risk-checker folder

### Step 2: Install and Run (2 minutes)

Open terminal/command prompt and run:

```bash
# Navigate to project folder
cd phone-risk-checker

# Install dependencies
pip install -r requirements.txt

# Run the server
python app.py
```

You should see:
```
Firebase initialized successfully
* Running on http://0.0.0.0:5000
```

### Step 3: Open the Website (1 minute)

1. Open `index.html` in your browser
2. Or visit: http://localhost:5000/api/health to verify API works

### Step 4: Test It! (2 minutes)

1. Enter a test phone number: `9876543210`
2. Click "Check This Number"
3. Try reporting it as scam
4. Check the number again - it should show as risky!

## 🎯 Integration with Your Website

### Option A: Simple iframe (Easiest)

Add this to your website HTML:

```html
<iframe 
  src="index.html" 
  width="100%" 
  height="800px" 
  frameborder="0">
</iframe>
```

### Option B: Direct Integration

Add this code to your website:

```html
<!-- Add this to your page -->
<div id="phone-checker"></div>

<!-- Add before </body> -->
<script src="phone-checker.js"></script>
<script>
  const checker = new PhoneRiskChecker('http://localhost:5000/api');
  checker.createWidget('phone-checker');
</script>
```

### Option C: Add to Contact Form

```html
<script src="phone-checker.js"></script>
<script>
document.getElementById('contactForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const phone = document.getElementById('phone').value;
  const checker = new PhoneRiskChecker('http://localhost:5000/api');
  
  const result = await checker.checkNumber(phone);
  
  if (result.risk.level === 'HIGH') {
    alert('⚠️ Warning: This number has been reported as high risk!');
  }
  
  // Continue with form submission
});
</script>
```

## 🌍 Making It Live (Production)

### Easiest: Render.com (100% Free)

1. Create GitHub account (if you don't have one)
2. Push your code to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/phone-checker.git
   git push -u origin main
   ```

3. Go to https://render.com
4. Sign up with GitHub
5. Click "New +" → "Web Service"
6. Connect your repository
7. Use these settings:
   - Name: phone-risk-checker
   - Environment: Python 3
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `gunicorn app:app --bind 0.0.0.0:$PORT`

8. Add environment variable:
   - Key: `API_KEY`
   - Value: `your-secure-key-123`

9. Add Firebase credentials:
   - Key: `GOOGLE_APPLICATION_CREDENTIALS_JSON`
   - Value: (paste entire content of serviceAccountKey.json)

10. Click "Create Web Service"

11. Wait 2-3 minutes. Your API will be live at: `https://your-app.onrender.com`

12. Update API URL in `index.html`:
    ```javascript
    const API_URL = 'https://your-app.onrender.com/api';
    ```

13. Deploy your frontend to Netlify (free):
    - Go to https://netlify.com
    - Drag and drop `index.html`
    - Done! Your website is live!

## 📚 For Rural Users - How to Explain

### In Simple Language:

**What is this tool?**
"यह एक फ़ोन नंबर चेकर है जो आपको बताता है कि कोई नंबर सुरक्षित है या नहीं।"

**How it works:**
1. किसी भी फ़ोन नंबर को डालें
2. देखें कि क्या दूसरे लोगों ने इसे रिपोर्ट किया है
3. अगर नंबर खतरनाक है तो हम आपको चेतावनी देंगे

**How to use:**
1. वह नंबर डालें जिसे चेक करना है
2. "Check This Number" बटन दबाएं
3. परिणाम देखें (हरा = सुरक्षित, लाल = खतरनाक)

## 🎓 Educational Content for Your Website

Add this section to teach users:

### Common Phone Scams in India:

1. **Bank OTP Scam**: कोई बैंक से कॉल करके OTP मांगता है
2. **Lottery Scam**: आपको लॉटरी जीतने का झूठा मैसेज
3. **KYC Update Scam**: बैंक KYC अपडेट के नाम पर लिंक भेजते हैं
4. **Job Scam**: नौकरी के नाम पर पैसे मांगना
5. **Police/Court Scam**: गिरफ्तारी की धमकी देकर पैसे मांगना

### Safety Rules:
- ✅ कभी भी OTP किसी को न बताएं
- ✅ अनजान लिंक पर क्लिक न करें
- ✅ जल्दबाजी में फैसला न लें
- ✅ संदिग्ध कॉल को रिपोर्ट करें
- ✅ परिवार को शिक्षित करें

## 📊 Track Your Impact

The system automatically tracks:
- Total numbers checked
- Total reports submitted
- High-risk numbers identified

Access stats at: `http://localhost:5000/api/stats`

## 🐛 Troubleshooting

### Problem: "Firebase not connected"
**Solution**: Check that `serviceAccountKey.json` is in the correct folder

### Problem: "Port 5000 already in use"
**Solution**: 
```bash
# Find and kill process
lsof -ti:5000 | xargs kill -9

# Or use different port
python app.py --port 8000
```

### Problem: "Module not found"
**Solution**:
```bash
pip install -r requirements.txt --upgrade
```

### Problem: CORS error in browser
**Solution**: Make sure flask-cors is installed and server is running

## 📱 Mobile App (Future)

You can use the same API to build:
- Android app
- iOS app
- WhatsApp bot
- SMS service
- USSD code (*123#)

## 🎉 Success Metrics

Track these to measure impact:
- Number of checks per day
- Number of reports submitted
- High-risk numbers prevented
- User feedback
- Lives protected from scams

## 📞 Support

Common questions:

**Q: Is it free?**
A: Yes! Firebase and Render free tier work perfectly.

**Q: How many users can it handle?**
A: Firebase free tier: 50K reads/day, 20K writes/day - enough for small communities

**Q: Can I customize it?**
A: Yes! Edit `index.html` for design, `app.py` for logic

**Q: What if someone reports wrong number?**
A: Rate limiting (5 reports/hour) prevents spam. You can add moderation later.

**Q: Does it work offline?**
A: No, requires internet. But you can add offline support later.

## 🚀 Next Steps

1. ✅ Get it running locally
2. ✅ Test with your community
3. ✅ Gather feedback
4. ✅ Deploy to production
5. ✅ Promote in your area
6. ✅ Track and improve

## 💡 Ideas for Enhancement

Once basic version works:
- Add WhatsApp integration
- SMS-based checking
- Voice call support
- Regional language support (Hindi, Telugu, Tamil, etc.)
- Offline mode
- Admin panel
- Analytics dashboard
- Educational videos
- Success stories section

## 🙏 Share Your Success

Once deployed, share:
- Number of users helped
- Scams prevented
- Community feedback
- Lessons learned

---

**Remember**: The goal is to protect rural communities from phone scams through education and technology! 🛡️

Start small, test often, grow gradually. You're making a difference! 🌟
